v# 모듈 설치 스크립트
opencv 모듈을 설치하지 않으면 confidence 관련 오류가 납니다.
```
pip install opencv-python
pip install pyperclip
pip install pyautogui
```

# 실행 스크립트
```
python sender.py
```
