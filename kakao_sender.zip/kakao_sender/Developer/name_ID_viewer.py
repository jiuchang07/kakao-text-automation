"""Accesses Blue Key Prep Bundang database that maps student name to student ID.

    author: Jiu Chang
    email: jiuchang@berkeley.edu
"""

import sys
import random
import json
from name_ID_dict import studentIDs
from exceptions import *

# The first 16 digits refer to the parent ID. The 17th digit refers to nth child from the parent. All student names are student names with a numeral at the end that distinguishes between possibly present duplicate student names.

def main():
    while True:
        print("학생의 이름과 아이디를 보실 수 있습니다. ")
        method_type = get_choice("어떻게 보시겠습니까?: (1) 반별, (2) 학부모별, (3) 이름별, (0) all", 6)
        if method_type == 1:
            by_class()
        elif method_type == 2:
            by_parent()
        elif method_type == 3:
            by_name()
        elif method_type == 0:
            all()

if __name__ == "__main__":
    main()
