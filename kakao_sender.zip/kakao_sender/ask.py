"""Asks for inputs from users, in appropriate formats, raising errors otherwise.

    author: Jiu Chang
    email: jiuchang@berkeley.edu
"""

import sys
import random
import json
from exceptions import *

def get_yes_or_no(prompt, neg_blank=False, pos_blank=False):
    positive = ["y", "yes", "예", "네", "ㅇ"]
    negative = ["n", "no", "아니오", "아니요", "ㄴ"]
    if neg_blank and pos_blank:
        print("Program intended an empty input to mean both negative and positive. By default, negative is chosen for any empty input.")
    if neg_blank:
        negative.append("")
    elif pos_blank:
        positive.append("")
    while True:
        try:
            result = input(prompt)
            if result not in positive and result not in negative:
                raise IncorrectFormat("(긍정) y, yes, 예, 네, ㅇ, (부정) n, no, 아니오, 아니요, ㄴ 중에 선택하시오")
            elif result in positive:
                return True
            else:
                return False
            break
        except IncorrectFormat:
            print(IncorrectFormat("(긍정) y, yes, 예, 네, ㅇ, (부정) n, no, 아니오, 아니요, ㄴ 중에 선택하시오"))
        
def get_choice(prompt, limit, lower_limit=0):
    while True:
        try:
            resp_str = input(prompt)
            if not resp_str.isnumeric():
                raise IncorrectFormat()
            elif int(resp_str) < lower_limit or int(resp_str) > limit:
                raise NotInRangeError(limit, lower_limit)
            return int(resp_str)
            break
        except IncorrectFormat:
            print(IncorrectFormat("숫자만 입력하십시오."))
        except NotInRangeError:
            print(NotInRangeError(limit, lower_limit))

def get_student_name(prompt):
    result = ""
    while True:
        try:
            result = input(prompt)
            if (result is None):
                raise TooShortError()
            check = get_yes_or_no(result+" 학생이 맞습니까? y/n: ", neg_blank=False, pos_blank=True)
            if check:
                return result
                break
        except TooShortError:
            print(TooShortError(1))

def get_parent_ID(prompt):
    while True:
        try:
            parent_ID_str = input(prompt)
            if (len(parent_ID_str) != 16):
                raise IncorrectLengthError("parent")
            elif (not parent_ID_str.isnumeric()):
                raise IncorrectFormat("숫자만 입력하십시오.")
            return int(parent_ID_str)
            break
        except IncorrectLengthError:
            print(IncorrectLengthError("parent"))
        except IncorrectFormat:
            print(IncorrectFormat("숫자만 입력하십시오."))
        
def get_student_ID(prompt):
    while True:
        try:
            student_ID_str = input(prompt)
            if (len(student_ID_str) != 17):
                raise IncorrectLengthError("student")
            elif (not student_ID_str.isnumeric()):
                raise IncorrectFormat("숫자만 입력하십시오.")
            return int(parent_ID_str)
            break
        except IncorrectLengthError:
            print(IncorrectLengthError("student"))
        except IncorrectFormat:
            print(IncorrectFormat("숫자만 입력하십시오."))
