"""Sends Kakao messages to parents automatically based on the imported Google Sheets data.

    author: Jiu Chang
    email: jiuchang@berkeley.edu
"""

from __future__ import print_function
import sys
import pyautogui
import time
import pyperclip
import os
import random
import re
import pickle
import os.path
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import json
from name_ID_dict import studentIDs
from ask import get_choice, get_yes_or_no, get_student_ID
from name_ID_editor import multiple_choice

# If modifying these scopes, delete the file token.pickle.
SCOPES = ['https://www.googleapis.com/auth/spreadsheets.readonly']

# The ID of Summer 2020 Blue Key Prep Bundang Attendance spreadsheet.
ATTENDENCE_SPREADSHEET_ID ='1JzdXG570gvfdzuofWG88LBOfB_sJaP-GVmSB-i9f7yY'

# List of classes
CLASS_NAMES = ["SAT 종합반 (오전)", "SAT Adv 종합반 (오후)", "SAT Basic 종합반 (오후)", "Jr.Elite A (MWF)", "Jr.Elite A (MWF) (오후)", "Jr.Elite B-7 (MWF)", "Jr.Elite B-8 (MWF)", "Jr. Elite KIS 8th Team", "Subject/Private"]

# Numbers for PER_WEEK
MTWTF = 5
MWF = 3
NON_WEEKLY = 20

# One call to python3 main_student_id.py sends 등원문자 to all students in one class, or selected students based on MODE.
# Upon each call, a range of values from the Google sheets is imported into an Imported object.
# An Imported has an attribute messages as a list of Message objects which each has the content of 등원문자 as an attribute.
# SEND_TO_ALL method sends 등원문자 to all students in the class.

################
# Core Classes #
################

class Imported(object):
    """An Imported contains the range of values imported from Google sheets."""
    
    def __init__(self, class_number, date, msg_type=False):
        """Create an Imported with the given CLASS_NAME.
        
        class_name -- A string; the name of the sheet pertaining to a class of the same name.
        """
        self.class_name = CLASS_NAMES[class_number - 1]
        self.values = []
        self.date = date
        self.msg_type = msg_type
        self.per_week = set_per_week(class_number)
        self.import_from_spreadsheet(self.class_name)
        self.messages = self.build_messages()
        
    def import_from_spreadsheet(self, class_name):
        """Set values to a new import."""
        if os.path.exists('token.pickle'):
            with open('token.pickle', 'rb') as token:
                creds = pickle.load(token)
        # If there are no (valid) credentials available, let the user log in.
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file(
                    'credentials.json', SCOPES)
                creds = flow.run_local_server(port=0)
            # Save the credentials for the next run
            with open('token.pickle', 'wb') as token:
                pickle.dump(creds, token)
        service = build('sheets', 'v4', credentials=creds)
        # Call the Sheets API
        sheet = service.spreadsheets()
        result = sheet.values().get(spreadsheetId=ATTENDENCE_SPREADSHEET_ID, range=class_name+'!A2:F100').execute()
        values = result.get('values', [])
        self.values = values
    
    def build_messages(self):
        """Put Message objects into MESSAGES. """
        message_list = []
        for r in range(len(self.values)):
            row = self.values[r]
            if row == []:
                pass
            elif end_of_the_week(row):
                break
            else:
                same_names = [s for s in studentIDs.keys() if s[:-1] in row[0]]
                if len(same_names) == 1:
                    message_list.append(Message(self.values, r, self.date, self.msg_type, self.per_week, same_names[0]))
                elif len(same_names) > 1:
                    same_name_IDs = list(dict.fromkeys([studentIDs[n] for n in same_names]))
                    if len(same_name_IDs) == 1:
                        message_list.append(Message(self.values, r, self.date, self.msg_type, self.per_week, same_names[0]))
                    else:
                        print(row[0])
                        student_ID = get_student_ID("\nMultiple students with the same name are found. Please input the target student's ID: ")
                        names = [name for name in studentIDs.keys() if studentIDs[name] == student_ID]
                        print(names)
                        message_list.append(Message(self.values, r, self.date, self.msg_type, self.per_week, names[0], student_ID))
        if message_list == []:
            print("\nno student found from dictionary")
        return message_list
            
class Message(object):
    """A Message contains information on the student ID, chat link and the contents of 등원문자. """
    
    def __init__(self, values, row_num, date, msg_type, per_week, sys_name, student_ID = None):
        self.values = values
        self.row_num = row_num
        self.date = date
        self.msg_type = msg_type
        self.per_week = per_week
        self.sys_name = sys_name
        self.raw_name = sys_name[:-1]
        self.studentID = studentIDs[sys_name]
        self.parentID = studentIDs[sys_name] // 10
        self.chatLink ='https://center-pf.kakao.com/_Visxlxb/chats/'+str(self.parentID)
        self.date_row = self.find_date_row()
        self.msg = self.form_msg()
        
    def __str__(self):
        return self.raw_name
    
    def form_msg(self):
        row = self.values[self.date_row]
        pattern_time = re.compile(r'(\d+):(\d+)')
        pattern_score = re.compile(r'\d+/\d\d')
        vocab = self.form_vocab(row, pattern_score)
        thank_you = "\n\n감사합니다."
        if self.msg_type == 1:
            title = "[등원 안내] \n\n" + self.raw_name + " 학생"
            if len(row) >= 2:
                time_full = pattern_time.match(row[1])
                if time_full is not None:
                    check_in_time = "\n" + time_full[1] + "시 " + time_full[2] + "분 등원"
                else:
                    print("등원 시각이 입력되지 않았습니다.")
                    return ""
            else:
                print("등원 시각이 입력되지 않았습니다.")
                return ""
            temperature = "\n" + row[2] + "˚C 정상체온"
            return title + check_in_time + temperature + vocab + thank_you
        if self.msg_type == 2:
            if pattern_score.match(row[-1]) is not None:
                title = "[단어시험 결과] \n\n" + self.raw_name + " 학생"
                return title + vocab + thank_you
            return ""
        if self.msg_type == 3:
            if len(row) >= 4:
                time_full = pattern_time.match(row[3])
                if time_full is not None:
                    check_in_time = "\n" + time_full[1] + "시 " + time_full[2] + "분 하원"
                else:
                    print("하원 시각이 입력되지 않았습니다.")
                    return ""
            else:
                print("하원 시각이 입력되지 않았습니다.")
                return ""
            title = "[하원 안내] \n\n" + self.raw_name + " 학생"
            return title + check_out_time + thank_you
        
    def form_vocab(self, row, pattern_score):
        if pattern_score.match(row[-1]):
            vocab_score = row[-1]
            score = "\n단어시험 "+str(vocab_score)
            if int(vocab_score[0:2]) >= 16:
                result = "\n통과입니다!"
            else:
                result = "\n재시험 봅니다."
            return score + result
        return ""

    def find_date_row(self):
        for i in range(self.per_week):
            if self.date in self.values[self.row_num + 1 + i][0]:
                return self.row_num + 1 + i
        print("\nno student found from dictionary")
        bye()
        


#########################
# Miscellenious Methods #
#########################

def end_of_the_week(row):
    return "SAT" in row[0] or "Jr. Elite"  in row[0] or "Tue, Thur" in row[0]
    
def set_per_week(class_number):
    if class_number == 1:
        return MTWTF
    elif class_number > 1 & class_number <= 7:
        return MWF
    else:
        return NON_WEEKLY

#####################
# PYAUTOGUI Methods #
#####################

def send_to_all(today_imported, mode, test=False):
    send_list = today_imported.messages.copy()
    if mode == 1:
        for s in send_list:
            print("Preview: \n\n"+ s.msg+"\n")
            should_send = get_yes_or_no(s.raw_name + " 학생에게 등원 문자를 보낼까요? y/n: ")
            if should_send:
                filter_friend(s.chatLink, 1)
                send_msg(s.msg, test)
    elif mode == 2:
        print("등원 문자를 보낼 학생은 "+multiple_choice(send_list, " 학생", ",\n")+"입니다.")
        call = 0
        while call < len(send_list):
            to_remove = get_choice("제외할 학생의 숫자를 하나씩 입력하십시오. 완료시에는 0을 눌러주십시오. ", len(send_list))
            if to_remove == 0:
                break
            else:
                call += 1
                send_list[to_remove - 1] = None
        send_list = list(filter(None, send_list))
        for s in send_list:
            filter_friend(s.chatLink, 1)
            send_msg(s.msg, test)
    elif mode == 3:
        print("등원 문자를 보낼 학생은 "+multiple_choice(send_list, " 학생", ",\n")+"입니다.")
        send_list_mode_3 = []
        call = 0
        while call < len(send_list):
            to_send = get_choice("문자 보낼 학생의 숫자를 하나씩 입력하십시오. 완료시에는 0을 눌러주십시오. ", len(send_list))
            if to_send == 0:
                break
            else:
                call += 1
                send_list_mode_3.append(send_list[to_send - 1])
        for s in send_list_mode_3:
            filter_friend(s.chatLink, 1)
            send_msg(s.msg, test)
            
def send_msg(my_msg, test=False):
    time_wait = random.uniform(3, 4)
    print(' // Time wait : ', time_wait)
    pyautogui.PAUSE
    pyautogui.press('enter')
    pyperclip.copy(my_msg)
    pyautogui.keyDown('ctrl')
    pyautogui.keyDown('v')
    pyautogui.PAUSE
    if not test:
        pyautogui.press('enter')

def filter_friend(filter_keyword, init_number):
    click_img_plus_x(img_path+'search_icon_plus.png', 10)
    pyautogui.PAUSE
    if filter_keyword == '':
        print("escape due to empty filter_keyword.")
        pyautogui.keyDown('esc')
    else:
        pyperclip.copy(filter_keyword)
    pyautogui.hotkey('ctrl', 'v')
    time.sleep(2)


def click_img(imagePath):
    location = pyautogui.locateCenterOnScreen(imagePath, confidence = conf)
    if location is None:
        print("화면에서 search_icon.png를 찾지 못했습니다.")
        exit()
    x, y = location
    x = x - 40
    y = y - 90
    pyautogui.click(x, y)
    pyautogui.PAUSE


def click_img_plus_x(imagePath, pixel):
    location = pyautogui.locateCenterOnScreen(imagePath, confidence = conf)
    if location is None:
        print("화면에서 search_icon.png를 찾지 못했습니다.")
        exit()
    x, y = location
    x = x - 40
    y = y - 90
    pyautogui.click(x + pixel, y)
    print(str(x+pixel)+", "+str(y)+" 클릭 후 검색을 실행합니다.")

def bye():
    print('프로그램이 종료되었습니다.')
    sys.exit()

# config
img_path = os.path.dirname(os.path.realpath(__file__)) + '/img/'
conf = 0.95
pyautogui.PAUSE = 0.5

def main():
    class_number = get_choice("등원 문자를 보낼 class: " + multiple_choice(CLASS_NAMES), len(CLASS_NAMES))
    date = input("\nDate (mm/dd): ")
    msg_type = get_choice("\n메시지 타입: \n(1) 등원 문자 FULL, \n(2) 단어 점수, \n(3) 하원 문자 (단어 불포함) \n", 3, 1)
    today_imported = Imported(class_number, date, msg_type)
    mode = get_choice("\n모드를 선택하십시오. \n(1) 일일이 확인 \n(2) 제외할 학생 선택 \n(3) 보낼 학생 선택 \n", 3, 1)
    test = get_yes_or_no("\ntest? y/n (press enter if no): ", True)
    send_to_all(today_imported, mode, test)
    bye()

if __name__ == "__main__":
    main()


