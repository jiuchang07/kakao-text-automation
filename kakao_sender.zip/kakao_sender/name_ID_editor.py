"""Edits Blue Key Prep Bundang database that maps student name to student ID.

    author: Jiu Chang
    email: jiuchang@berkeley.edu
"""

import sys
import random
import json
from name_ID_dict import studentIDs
from exceptions import *
from ask import *

# The first 16 digits refer to the parent ID. The 17th digit refers to nth child from the parent. All student names are student names with a numeral at the end that distinguishes between possibly present duplicate student names.

def view():
    for k, v in studentIDs.items():
        print(k + "\t" + str(v))
    print()

def add(raw_name=None, parent_ID=None):
    if raw_name is None:
        raw_name = get_student_name("학생 이름을 입력하시오: ")
    if parent_ID is None:
        parent_ID = get_parent_ID("학부모 ID를 입력하시오 (카카오 채팅 페이지 링크 뒷부분): ")
    sibling_IDs = find_sibling_IDs(parent_ID)
    if name_exists(raw_name) & (sibling_IDs != []):
        same_names = find_same_names(raw_name)
        for name in same_names:
            if studentIDs[name] in sibling_IDs:
                print("이미 등록된 학생입니다. ID: " + str(sibling_IDs))
                print()
                return
        case_duplicate_name(raw_name+str(len(same_names)), parent_ID, sibling_IDs)
    elif sibling_IDs:
        case_duplicate_name(raw_name+"0", parent_ID, sibling_IDs)
    elif name_exists(raw_name):
        same_names = find_same_names(raw_name)
        studentIDs[raw_name+str(len(same_names))] = parent_ID * 10
    else:
        studentIDs[raw_name+"0"] = parent_ID * 10
    print(raw_name+" 학생이 성공적으로 등록되었습니다.\n")

def update_name():
    raw_name = get_student_name("학생의 기존 이름을 입력하시오. ")
    same_names = find_same_names(raw_name)
    if len(same_names) == 0:
        print("미등록된 학생입니다.\n")
        return
    elif len(same_names) == 1:
        sys_name = raw_name+"0"
        student_ID = studentIDs[sys_name]
    else:
        parent_ID = get_parent_ID("중복되는 이름입니다. 학생의 학부모 ID를 입력해주십시오. ")
        for name in same_names:
            if parent_ID in studentIDs[name]:
                sys_name = name
                student_ID = studentIDs[name]
        if sys_name is None or student_ID is None:
            print("학부모 ID를 찾지 못했습니다. 처음부터 다시 검색해주십시오.\n")
            return
    new_name = get_student_name("학생의 신규 이름을 입력하시오. ")
    add(new_name, student_ID//10)
    delete_name(raw_name)
    
def delete_name(raw_name=None):
    if raw_name is None:
        raw_name = get_student_name("삭제할 학생 이름을 입력하시오. ")
    same_names = find_same_names(raw_name)
    sys_name = ""
    student_ID = 0
    if len(same_names) == 0:
        print("미등록된 학생입니다.\n")
        return
    elif len(same_names) == 1:
        sys_name = same_names[0]
    else:
        parent_ID = get_parent_ID("중복되는 이름입니다. 학생의 학부모 ID를 입력해주십시오. ")
        for name in same_names:
            if parent_ID == studentIDs[name] // 10:
                sys_name = name
                student_ID = studentIDs[name]
                break
        if sys_name == "" or student_ID == 0:
            print("학부모 ID를 찾지 못했습니다. 처음부터 다시 검색해주십시오.\n")
            return
    studentIDs.pop(sys_name)
    reset_name_index(sys_name, same_names)
    print(sys_name+" 학생 이름이 삭제되었습니다.\n")
    
def save(studentIDs):
    studentIDs_sorted = {k: v for k, v in sorted(studentIDs.items(), key=lambda item: item[1])}
    with open('name_ID_dict.py','w') as f:
        f.write('studentIDs = '+json.dumps(studentIDs_sorted))
    print("저장되었습니다.\n")
    
def reset_name_index(sys_name, same_names):
    same_names.remove(sys_name)
    for i in range(len(same_names)):
        name = same_names[i]
        studentIDs[name[-1:] + str(i)] = studentIDs[name]
        studentIDs.pop(name)
    
def case_duplicate_name(sys_name, parent_ID, sibling_IDs):
    names_from_parent = find_names_from_parent(parent_ID)
    alt = get_choice("\n이미 등록된 학부모가 있습니다. 아래 이름 중 동일한 학생을 가리키는 다른 이름이 있다면 그 숫자를, 없다면 0을 입력해주십시오. " + multiple_choice(names_from_parent), len(names_from_parent))
    if alt == 0:
        studentIDs[sys_name] = max(sibling_IDs) + 1
    else:
        studentIDs[sys_name] = studentIDs[names_from_parent[int(alt)-1]]

def multiple_choice(ls, tail="", delimiter="\n"):
    """Return a string that weaves each LS entry as multiple choice, separated by an optional TAIL that comes after every entry and an optional DELIMITER that separates each choice.
    
    ls -- A list that contains the choices.
    tail -- An optional string that comes after every entry
    delimiter -- An optional string that separates each entry.
    """
    text = "\n"
    for i in range(len(ls) - 1):
        text += "(" + str(i + 1) + ") " + str(ls[i]) + tail + delimiter
    text += "(" + str(len(ls)) + ") " + str(ls[len(ls) - 1]) + tail + "\n"
    return text
        
def name_exists(raw_name):
    return raw_name+"0" in studentIDs.keys()
    
def find_same_names(raw_name):
    """List of student system names with the STUDENT_NAME."""
    return [n for n in studentIDs.keys() if n[:-1] in raw_name]
    
def find_sibling_IDs(parent_ID):
    """List of student IDs with the same parent."""
    return list(dict.fromkeys([s for s in studentIDs.values() if parent_ID == s//10]))

def find_names_from_parent(parent_ID):
    """List of student system names with the same parent."""
    return [name for name in studentIDs.keys() if parent_ID == studentIDs[name]//10]
    
def main():
    while True:
        method_type = get_choice("실행할 액션의 숫자를 입력하시오: (1) view, (2) add, (3) update student name, (4) delete, (5) save, (6) quit without saving, (0) save & quit ", 6)
        if method_type == 1:
            view()
        elif method_type == 2:
            add()
        elif method_type == 3:
            update_name()
        elif method_type == 4:
            delete_name()
        elif method_type == 5:
            save(studentIDs)
        elif method_type == 6:
            print("프로그램을 종료합니다.\n")
            break
        elif method_type == 0:
            save(studentIDs)
            print("프로그램을 종료합니다.\n")
            break

if __name__ == "__main__":
    main()
